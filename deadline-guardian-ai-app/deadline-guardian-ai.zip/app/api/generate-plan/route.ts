import { GoogleGenerativeAI } from "@google/generative-ai";
import { NextResponse } from "next/server";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const {
      missionName,
      deadline,
      description,
      priority,
      hoursPerDay,
    } = body;

    const model = genAI.getGenerativeModel({
      model: "gemini-2.5-flash",
    });

    const prompt = `
You are an expert productivity coach.

Create a structured execution plan.

Mission:
${missionName}

Deadline:
${deadline}

Description:
${description}

Priority:
${priority}

Available Hours Per Day:
${hoursPerDay}

Return ONLY valid JSON.

Format:

{
  "summary":"",
  "riskLevel":"",
  "estimatedHours":0,
  "timeline":[
    {
      "day":"Day 1",
      "task":""
    }
  ],
  "tips":[
    ""
  ]
}
`;

    const result = await model.generateContent(prompt);

    const text = result.response.text();

    return NextResponse.json({
      success: true,
      response: text,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        success: false,
        message: "Failed to generate plan.",
      },
      {
        status: 500,
      }
    );
  }
}